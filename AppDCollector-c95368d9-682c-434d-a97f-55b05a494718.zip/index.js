const xraytrace = require('./lib/xraytrace');
const appdevents = require('./lib/appdevents');
const moment = require('./lib/moment');
const http = require('http');

const appd = new appdevents("44controllerevents-44buiqkdtake2-1jzw5zap.srv.ravcloud.com", "customer1_691446bf-6db3-4f81-a571-64a572e2e5c5","1ebe4471-94da-4c32-9189-47890c207cc1");

exports.handler = (event, context, callback) => {
    
  
    xraytrace.getTraceIds(moment().subtract(2,'minutes').toDate(), moment().toDate(), function(err,ids) {
        
        if(err) {
            callback(err,null);
        }
        xraytrace.traceToEvents(ids,function(err,events) {
       
         if(err){
                callback(err,null);
            }
        
      
            appd.sendevents(events,function(err){
             if(err){
                    callback(err);
                }
            });

        } );
    });


    callback(null, 'Success');
};